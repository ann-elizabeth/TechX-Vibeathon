'use client';

import { UserProfile, CareerRoadmap } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface HomeViewProps {
  profile: UserProfile;
  roadmap: CareerRoadmap | null;
  onNavigate: (section: string) => void;
}

export function HomeView({ profile, roadmap, onNavigate }: HomeViewProps) {
  if (!roadmap) return null;

  const completedTasks = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = roadmap.tasks.length;
  const progressPercent = Math.round((completedTasks / totalTasks) * 100);

  const pendingTasks = roadmap.tasks.filter((t) => t.status === 'pending');
  const nextTask = pendingTasks[0];

  const currentPhaseEmoji = {
    foundation: '🔨',
    growth: '📈',
    mastery: '⭐',
    leadership: '👑',
  }[roadmap.phase];

  const currentPhaseDescription = {
    foundation: 'Build core skills and understanding the fundamentals',
    growth: 'Expand expertise with specialized skills and complex projects',
    mastery: 'Become an expert and lead initiatives in your domain',
    leadership: 'Strategic thinking and organizational impact',
  }[roadmap.phase];

  const categoryStats = {
    skill: roadmap.tasks.filter((t) => t.category === 'skill').length,
    project: roadmap.tasks.filter((t) => t.category === 'project').length,
    learning: roadmap.tasks.filter((t) => t.category === 'learning').length,
    networking: roadmap.tasks.filter((t) => t.category === 'networking').length,
  };

  const totalHours = roadmap.tasks.reduce((sum, t) => sum + t.estimatedHours, 0);
  const completedHours = roadmap.tasks
    .filter((t) => t.status === 'completed')
    .reduce((sum, t) => sum + t.estimatedHours, 0);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <Card className="border-0 shadow-xl backdrop-blur-sm bg-gradient-to-r from-primary/20 via-accent/20 to-primary/10 overflow-hidden animate-fadeInUp">
        <CardContent className="pt-8 pb-8">
          <div className="flex items-center justify-between gap-6">
            <div className="space-y-3">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Welcome back, {profile.name}!
              </h2>
              <p className="text-foreground/70 text-lg max-w-2xl">
                You're on track with your career development. Keep pushing forward!
              </p>
            </div>
            <div className="text-6xl">{currentPhaseEmoji}</div>
          </div>
        </CardContent>
      </Card>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Progress */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-primary/15 to-primary/5 hover:shadow-xl transition-smooth animate-slideInLeft">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Overall Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              {progressPercent}%
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              {completedTasks} of {totalTasks} tasks completed
            </p>
          </CardContent>
        </Card>

        {/* Time Invested */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-accent/15 to-accent/5 hover:shadow-xl transition-smooth animate-slideInLeft" style={{ animationDelay: '0.05s' }}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Time Invested</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                {Math.round(completedHours)}h
              </span>
              <span className="text-sm text-muted-foreground">/ {totalHours}h</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-accent to-primary transition-all duration-500"
                style={{ width: `${(completedHours / totalHours) * 100}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              {Math.round(((totalHours - completedHours) / totalHours) * 100)}% remaining
            </p>
          </CardContent>
        </Card>

        {/* Current Phase */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-primary/15 to-accent/10 hover:shadow-xl transition-smooth animate-slideInRight">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Current Phase</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-2xl font-bold capitalize text-foreground">{roadmap.phase}</p>
            <p className="text-xs text-muted-foreground line-clamp-2">{currentPhaseDescription}</p>
          </CardContent>
        </Card>

        {/* Next Task */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-accent/15 to-primary/10 hover:shadow-xl transition-smooth animate-slideInRight" style={{ animationDelay: '0.05s' }}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase">Next Up</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {nextTask ? (
              <>
                <p className="font-semibold text-foreground line-clamp-2">{nextTask.title}</p>
                <Badge variant="outline" className="w-fit text-xs">
                  ⏱️ {nextTask.estimatedHours}h
                </Badge>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">All tasks completed!</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Current Status & Next Steps */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Task Breakdown */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 hover:shadow-xl transition-smooth animate-slideInLeft">
          <CardHeader className="pb-4 border-b border-border/30">
            <CardTitle className="flex items-center gap-2">
              <span className="text-xl">📋</span>
              Task Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-green-500/10 border border-green-500/30">
              <span className="font-medium text-sm">Completed</span>
              <span className="text-2xl font-bold text-green-600">{completedTasks}</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
              <span className="font-medium text-sm">In Progress</span>
              <span className="text-2xl font-bold text-blue-600">
                {roadmap.tasks.filter((t) => t.status === 'in-progress').length}
              </span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
              <span className="font-medium text-sm">Pending</span>
              <span className="text-2xl font-bold text-yellow-600">
                {roadmap.tasks.filter((t) => t.status === 'pending').length}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Skills Overview */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 hover:shadow-xl transition-smooth animate-slideInLeft" style={{ animationDelay: '0.05s' }}>
          <CardHeader className="pb-4 border-b border-border/30">
            <CardTitle className="flex items-center gap-2">
              <span className="text-xl">⚡</span>
              Current Skills
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="flex flex-wrap gap-2">
              {profile.currentSkills.slice(0, 5).map((skill) => (
                <Badge key={skill} className="bg-gradient-to-r from-primary to-accent text-white">
                  {skill}
                </Badge>
              ))}
              {profile.currentSkills.length > 5 && (
                <Badge variant="outline">+{profile.currentSkills.length - 5} more</Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              {profile.careerGoal}
            </p>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 hover:shadow-xl transition-smooth animate-slideInRight">
          <CardHeader className="pb-4 border-b border-border/30">
            <CardTitle className="flex items-center gap-2">
              <span className="text-xl">📊</span>
              Task Categories
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Skills</span>
              <Badge variant="secondary">{categoryStats.skill}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Projects</span>
              <Badge variant="secondary">{categoryStats.project}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Learning</span>
              <Badge variant="secondary">{categoryStats.learning}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Networking</span>
              <Badge variant="secondary">{categoryStats.networking}</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          onClick={() => onNavigate('roadmap')}
          className="h-20 bg-gradient-to-r from-primary to-accent text-white hover:shadow-lg transition-smooth text-base font-semibold rounded-lg border-0 animate-slideInLeft"
        >
          <div className="flex flex-col items-center gap-1">
            <span className="text-2xl">🗺️</span>
            <span>View Full Roadmap</span>
          </div>
        </Button>

        <Button
          onClick={() => onNavigate('progress')}
          variant="outline"
          className="h-20 hover:bg-accent/10 hover:border-accent transition-smooth text-base font-semibold rounded-lg animate-slideInLeft"
          style={{ animationDelay: '0.1s' }}
        >
          <div className="flex flex-col items-center gap-1">
            <span className="text-2xl">📊</span>
            <span>Detailed Progress</span>
          </div>
        </Button>

        <Button
          onClick={() => onNavigate('chat')}
          variant="outline"
          className="h-20 hover:bg-accent/10 hover:border-accent transition-smooth text-base font-semibold rounded-lg animate-slideInRight"
        >
          <div className="flex flex-col items-center gap-1">
            <span className="text-2xl">💬</span>
            <span>Ask AI Coach</span>
          </div>
        </Button>
      </div>
    </div>
  );
}
