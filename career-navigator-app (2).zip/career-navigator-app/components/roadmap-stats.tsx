'use client';

import { CareerRoadmap } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface RoadmapStatsProps {
  roadmap: CareerRoadmap;
}

export function RoadmapStats({ roadmap }: RoadmapStatsProps) {
  const totalTasks = roadmap.tasks.length;
  const completed = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const inProgress = roadmap.tasks.filter((t) => t.status === 'in-progress').length;
  const pending = roadmap.tasks.filter((t) => t.status === 'pending').length;

  const avgDifficulty = Math.round(
    roadmap.tasks.reduce((sum, t) => sum + t.difficulty, 0) / totalTasks
  );

  const totalHours = roadmap.tasks.reduce((sum, t) => sum + t.estimatedHours, 0);
  const completedHours = roadmap.tasks
    .filter((t) => t.status === 'completed')
    .reduce((sum, t) => sum + t.estimatedHours, 0);

  const skillCount = new Set(roadmap.tasks.flatMap((t) => t.skills)).size;

  const completionRate = Math.round((completed / totalTasks) * 100);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-green-500/10 to-green-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Completed</p>
            <p className="text-3xl font-bold text-green-600">{completed}</p>
            <p className="text-xs text-muted-foreground">{completionRate}%</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-blue-500/10 to-blue-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Active</p>
            <p className="text-3xl font-bold text-blue-600">{inProgress}</p>
            <p className="text-xs text-muted-foreground">in progress</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-yellow-500/10 to-yellow-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Pending</p>
            <p className="text-3xl font-bold text-yellow-600">{pending}</p>
            <p className="text-xs text-muted-foreground">to start</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-purple-500/10 to-purple-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Difficulty</p>
            <p className="text-3xl font-bold text-purple-600">{avgDifficulty}</p>
            <p className="text-xs text-muted-foreground">average</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-orange-500/10 to-orange-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Time</p>
            <p className="text-3xl font-bold text-orange-600">{Math.round(completedHours)}</p>
            <p className="text-xs text-muted-foreground">of {totalHours}h</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-md backdrop-blur-sm bg-gradient-to-br from-pink-500/10 to-pink-500/5">
        <CardContent className="pt-4">
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase">Skills</p>
            <p className="text-3xl font-bold text-pink-600">{skillCount}</p>
            <p className="text-xs text-muted-foreground">to develop</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
