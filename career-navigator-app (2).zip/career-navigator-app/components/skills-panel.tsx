'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SkillMetrics } from '@/lib/skill-engine';

interface SkillsPanelProps {
  userSkills: string[];
}

export function SkillsPanel({ userSkills }: SkillsPanelProps) {
  const [recommendedSkills, setRecommendedSkills] = useState<SkillMetrics[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const skillsParam = userSkills.join(',');
        const response = await fetch(
          `/api/data/skills?action=recommend&userSkills=${encodeURIComponent(skillsParam)}&limit=5`
        );
        const data = await response.json();
        setRecommendedSkills(data.skills || []);
      } catch (error) {
        console.error('Error fetching skill recommendations:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecommendations();
  }, [userSkills]);

  return (
    <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 hover:shadow-xl transition-smooth animate-slideInLeft" style={{ animationDelay: '0.1s' }}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent flex items-center gap-2">
          <span>⚡</span> Your Skills
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-3">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Mastered Skills</p>
          <div className="flex flex-wrap gap-2">
            {userSkills.map((skill, idx) => (
              <Badge key={skill} variant="default" className="bg-gradient-to-r from-primary to-accent text-white font-medium animate-scaleIn" style={{ animationDelay: `${idx * 0.05}s` }}>
                ✓ {skill}
              </Badge>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-border/30">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-foreground">Next to Learn</h3>
            <span className="text-xs font-semibold text-accent">Market Demand</span>
          </div>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-8 bg-muted/30 rounded animate-pulseSoft"></div>
              ))}
            </div>
          ) : recommendedSkills.length > 0 ? (
            <div className="space-y-2">
              {recommendedSkills.map((skill, idx) => {
                const demandPercent = Math.round(skill.demandScore * 100);
                return (
                  <div key={skill.skill} className="p-2 rounded-lg bg-accent/5 hover:bg-accent/10 transition-smooth animate-fadeInUp" style={{ animationDelay: `${idx * 0.1}s` }}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-sm">{skill.skill}</span>
                      <span className="text-xs font-bold text-accent">{demandPercent}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500" style={{ width: `${demandPercent}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-xs text-muted-foreground p-2 text-center">No recommendations available</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
