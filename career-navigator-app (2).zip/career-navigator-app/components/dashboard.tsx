'use client';

import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserProfile, CareerRoadmap } from '@/lib/types';
import { clientStorage } from '@/lib/storage';
import { RoadmapView } from './roadmap-view';
import { DetailedRoadmap } from './roadmap-detailed';
import { HomeView } from './home-view';
import { ChatInterface } from './chat-interface';
import { SkillsPanel } from './skills-panel';
import { ProgressTracker } from './progress-tracker';

interface DashboardProps {
  profile: UserProfile;
}

export function Dashboard({ profile: initialProfile }: DashboardProps) {
  const [profile, setProfile] = useState(initialProfile);
  const [roadmap, setRoadmap] = useState<CareerRoadmap | null>(null);
  const [activeTab, setActiveTab] = useState('home');

  useEffect(() => {
    const savedRoadmap = clientStorage.getRoadmap();
    setRoadmap(savedRoadmap);
  }, []);

  const handleLogout = () => {
    clientStorage.clear();
    window.location.reload();
  };

  const handleTaskComplete = (taskId: string) => {
    if (!roadmap) return;

    const updatedTasks = roadmap.tasks.map((task) => {
      if (task.id === taskId && task.status !== 'completed') {
        return {
          ...task,
          status: 'completed' as const,
          completedAt: new Date(),
          updatedAt: new Date(),
        };
      }
      return task;
    });

    const completedCount = updatedTasks.filter((t) => t.status === 'completed').length;
    const completionRate = (completedCount / updatedTasks.length) * 100;

    const updatedRoadmap = {
      ...roadmap,
      tasks: updatedTasks,
      completionRate,
      updatedAt: new Date(),
    };

    setRoadmap(updatedRoadmap);
    clientStorage.saveRoadmap(updatedRoadmap);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/20 to-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 animate-fadeInUp">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-white font-bold">CN</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">Career Navigator</h1>
                <p className="text-xs text-muted-foreground">
                  Welcome back, <span className="font-medium text-foreground">{profile.name}</span>
                </p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout} className="transition-smooth hover:bg-accent hover:text-accent-foreground">
              Start Over
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Profile Card */}
            <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 hover:shadow-xl transition-smooth animate-slideInLeft">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent flex items-center gap-2">
                  <span>👤</span> Your Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="p-3 rounded-lg bg-primary/5">
                  <p className="text-muted-foreground text-xs font-semibold">CURRENT ROLE</p>
                  <p className="font-semibold text-foreground mt-1">{profile.currentRole}</p>
                </div>
                <div className="p-3 rounded-lg bg-accent/5">
                  <p className="text-muted-foreground text-xs font-semibold">EXPERIENCE</p>
                  <p className="font-semibold text-foreground mt-1">{profile.yearsOfExperience} years</p>
                </div>
                {profile.targetRole && (
                  <div className="p-3 rounded-lg bg-primary/5">
                    <p className="text-muted-foreground text-xs font-semibold">TARGET ROLE</p>
                    <p className="font-semibold text-foreground mt-1">{profile.targetRole}</p>
                  </div>
                )}
                {profile.targetSalary && (
                  <div className="p-3 rounded-lg bg-accent/5">
                    <p className="text-muted-foreground text-xs font-semibold">TARGET SALARY</p>
                    <p className="font-semibold text-foreground mt-1">
                      ${profile.targetSalary.toLocaleString()}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Skills Card */}
            <SkillsPanel userSkills={profile.currentSkills} />
          </div>

          {/* Main Panel */}
          <div className="lg:col-span-3 animate-slideInRight">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-card/80 border border-border/50 backdrop-blur-sm">
                <TabsTrigger value="home" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-accent data-[state=active]:text-white transition-smooth">
                  🏠 Home
                </TabsTrigger>
                <TabsTrigger value="roadmap" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-accent data-[state=active]:text-white transition-smooth">
                  🗺️ Roadmap
                </TabsTrigger>
                <TabsTrigger value="progress" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-accent data-[state=active]:text-white transition-smooth">
                  📊 Progress
                </TabsTrigger>
                <TabsTrigger value="chat" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-accent data-[state=active]:text-white transition-smooth">
                  💬 AI Coach
                </TabsTrigger>
              </TabsList>

              <TabsContent value="home" className="space-y-4 animate-fadeInUp">
                {roadmap && (
                  <HomeView
                    profile={profile}
                    roadmap={roadmap}
                    onNavigate={setActiveTab}
                  />
                )}
              </TabsContent>

              <TabsContent value="roadmap" className="space-y-4 animate-fadeInUp">
                {roadmap ? (
                  <DetailedRoadmap
                    roadmap={roadmap}
                    onTaskComplete={handleTaskComplete}
                  />
                ) : (
                  <Card className="border-0 shadow-lg bg-gradient-to-br from-primary/5 to-accent/5 backdrop-blur-sm">
                    <CardContent className="pt-8 pb-8 flex items-center justify-center">
                      <div className="text-center space-y-3">
                        <div className="animate-pulseSoft text-3xl">⏳</div>
                        <p className="text-muted-foreground font-medium">Loading your roadmap...</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="progress" className="space-y-4 animate-fadeInUp">
                {roadmap && (
                  <ProgressTracker roadmap={roadmap} />
                )}
              </TabsContent>

              <TabsContent value="chat" className="space-y-4 animate-fadeInUp">
                {roadmap && (
                  <ChatInterface
                    profile={profile}
                    roadmap={roadmap}
                  />
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}
