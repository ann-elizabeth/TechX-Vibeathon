'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { clientStorage } from '@/lib/storage';
import { UserProfile } from '@/lib/types';
import { runGoalSetter } from '@/lib/agents/goal-setter';
import { runDecomposer } from '@/lib/agents/decomposer';

export function OnboardingFlow() {
  const [step, setStep] = useState<'profile' | 'goal' | 'loading'>('profile');
  const [name, setName] = useState('');
  const [currentRole, setCurrentRole] = useState('');
  const [yearsOfExp, setYearsOfExp] = useState('');
  const [skills, setSkills] = useState('');
  const [aspirations, setAspirations] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setStep('loading');

    try {
      // Create user profile
      const profile: UserProfile = {
        id: `user_${Date.now()}`,
        name,
        currentRole,
        yearsOfExperience: parseInt(yearsOfExp),
        currentSkills: skills
          .split(',')
          .map((s) => s.trim())
          .filter((s) => s),
        careerGoal: aspirations,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Run Goal Setter agent
      const goalResult = await fetch('/api/agents/goal-setter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentRole,
          currentSkills: profile.currentSkills,
          yearsOfExperience: profile.yearsOfExperience,
          careerAspirations: aspirations,
        }),
      }).then((res) => res.json());

      profile.targetRole = goalResult.targetRole;
      profile.targetSalary = goalResult.targetSalaryRange.max;

      // Run Task Decomposer agent
      const decomposerResult = await fetch('/api/agents/decomposer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goal: goalResult.primaryGoal,
          targetRole: goalResult.targetRole,
          timelineMonths: goalResult.timelineMonths,
          requiredSkills: [
            ...profile.currentSkills,
            ...goalResult.recommendedSkills?.map((s: { skill: string }) => s.skill) || [],
          ],
          currentSkills: profile.currentSkills,
        }),
      }).then((res) => res.json());

      // Create roadmap
      const allTasks = [
        ...decomposerResult.phase1,
        ...decomposerResult.phase2,
        ...decomposerResult.phase3,
        ...decomposerResult.phase4,
      ];

      const roadmap = {
        id: `roadmap_${Date.now()}`,
        userId: profile.id,
        goal: goalResult.primaryGoal,
        phase: 'foundation' as const,
        tasks: allTasks,
        currentPhaseIndex: 0,
        completionRate: 0,
        lastEvaluatedAt: new Date(),
        nextEvaluationAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Save to storage
      clientStorage.saveProfile(profile);
      clientStorage.saveRoadmap(roadmap);

      // Reload page to show dashboard
      window.location.reload();
    } catch (error) {
      console.error('Error creating profile:', error);
      setIsLoading(false);
      setStep('profile');
    }
  };

  if (isLoading || step === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse opacity-30"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse opacity-30" style={{ animationDelay: '1s' }}></div>
        </div>
        <Card className="w-full max-w-md shadow-2xl border-0 backdrop-blur-sm bg-white/95 dark:bg-slate-950/95 relative z-10 animate-scaleIn">
          <CardContent className="pt-8 flex flex-col items-center gap-6">
            <div className="relative w-16 h-16">
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-full animate-spin" style={{ animationDuration: '3s' }}></div>
              <div className="absolute inset-2 bg-white dark:bg-slate-950 rounded-full"></div>
            </div>
            <div className="text-center space-y-2">
              <p className="font-semibold text-lg text-foreground">Generating Your Roadmap</p>
              <p className="text-sm text-muted-foreground">Our AI agents are analyzing your profile...</p>
              <div className="flex items-center justify-center gap-1 pt-2">
                <div className="w-2 h-2 bg-primary rounded-full animate-pulseSoft" style={{ animationDelay: '0s' }}></div>
                <div className="w-2 h-2 bg-accent rounded-full animate-pulseSoft" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-primary rounded-full animate-pulseSoft" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse opacity-30"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse opacity-30" style={{ animationDelay: '1s' }}></div>
      </div>
      <div className="w-full max-w-2xl relative z-10">
        <Card className="shadow-2xl border-0 backdrop-blur-sm bg-white/95 dark:bg-slate-950/95 animate-fadeInUp">
          <CardHeader className="space-y-2 pb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-scaleIn">
                <span className="text-white font-bold text-lg">CN</span>
              </div>
              <div>
                <CardTitle className="text-3xl bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Career Navigator</CardTitle>
                <CardDescription className="text-xs mt-1">AI-Powered Career Growth</CardDescription>
              </div>
            </div>
            <p className="text-foreground/70 text-sm">Build your personalized roadmap powered by real market data and AI insights</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleProfileSubmit} className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2 animate-slideInLeft">
                  <Label htmlFor="name" className="font-medium text-sm">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="John Developer"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="transition-smooth border-border/50 focus:border-primary h-10"
                  />
                </div>
                <div className="space-y-2 animate-slideInRight">
                  <Label htmlFor="role" className="font-medium text-sm">Current Role</Label>
                  <Input
                    id="role"
                    placeholder="e.g., Frontend Developer"
                    value={currentRole}
                    onChange={(e) => setCurrentRole(e.target.value)}
                    required
                    className="transition-smooth border-border/50 focus:border-primary h-10"
                  />
                </div>
              </div>

              <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '0.1s' }}>
                <Label htmlFor="experience" className="font-medium text-sm">Years of Experience</Label>
                <Input
                  id="experience"
                  type="number"
                  min="0"
                  max="50"
                  placeholder="3"
                  value={yearsOfExp}
                  onChange={(e) => setYearsOfExp(e.target.value)}
                  required
                  className="transition-smooth border-border/50 focus:border-primary h-10"
                />
              </div>

              <div className="space-y-2 animate-slideInRight" style={{ animationDelay: '0.1s' }}>
                <Label htmlFor="skills" className="font-medium text-sm">Current Skills (comma-separated)</Label>
                <Textarea
                  id="skills"
                  placeholder="JavaScript, React, Node.js, TypeScript, CSS"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="transition-smooth border-border/50 focus:border-primary min-h-20 resize-none"
                  required
                />
              </div>

              <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '0.2s' }}>
                <Label htmlFor="aspirations" className="font-medium text-sm">Career Aspirations & Goals</Label>
                <Textarea
                  id="aspirations"
                  placeholder="What roles interest you? What salary range are you targeting? Any specific companies or industries?"
                  value={aspirations}
                  onChange={(e) => setAspirations(e.target.value)}
                  className="transition-smooth border-border/50 focus:border-primary min-h-24 resize-none"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full h-11 text-base font-semibold bg-gradient-to-r from-primary to-accent hover:shadow-lg transition-smooth animate-slideInRight" 
                size="lg"
                disabled={isLoading}
                style={{ animationDelay: '0.2s' }}
              >
                {isLoading ? 'Generating...' : 'Generate My Roadmap'}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card className="border-0 backdrop-blur-sm bg-gradient-to-br from-primary/5 to-primary/10 hover:shadow-lg transition-smooth animate-slideInLeft" style={{ animationDelay: '0.3s' }}>
            <CardContent className="pt-6">
              <div className="text-center space-y-2">
                <div className="text-3xl">🤖</div>
                <div className="text-lg font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">AI-Powered</div>
                <p className="text-sm text-muted-foreground">Smart goal-setting and planning</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 backdrop-blur-sm bg-gradient-to-br from-accent/5 to-accent/10 hover:shadow-lg transition-smooth animate-slideInLeft" style={{ animationDelay: '0.4s' }}>
            <CardContent className="pt-6">
              <div className="text-center space-y-2">
                <div className="text-3xl">📊</div>
                <div className="text-lg font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Real Data</div>
                <p className="text-sm text-muted-foreground">Based on LinkedIn insights</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 backdrop-blur-sm bg-gradient-to-br from-primary/5 to-primary/10 hover:shadow-lg transition-smooth animate-slideInRight" style={{ animationDelay: '0.3s' }}>
            <CardContent className="pt-6">
              <div className="text-center space-y-2">
                <div className="text-3xl">🎯</div>
                <div className="text-lg font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Dynamic</div>
                <p className="text-sm text-muted-foreground">Evolves with your progress</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
