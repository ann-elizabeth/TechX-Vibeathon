'use client';

import { CareerRoadmap, RoadmapTask } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';

interface RoadmapViewProps {
  roadmap: CareerRoadmap;
  onTaskComplete: (taskId: string) => void;
}

const phaseNames = {
  foundation: 'Foundation (0-6 months)',
  growth: 'Growth (6-12 months)',
  mastery: 'Mastery (12-18 months)',
  leadership: 'Leadership (18+ months)',
};

const categoryColors = {
  skill: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  project: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  learning: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  networking: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
};

const difficultyColors = {
  low: 'text-green-600',
  medium: 'text-yellow-600',
  high: 'text-red-600',
};

function getDifficultyLabel(difficulty: number) {
  if (difficulty <= 3) return { label: 'Easy', color: 'text-green-600' };
  if (difficulty <= 6) return { label: 'Medium', color: 'text-yellow-600' };
  return { label: 'Hard', color: 'text-red-600' };
}

function TaskCard({
  task,
  onComplete,
}: {
  task: RoadmapTask;
  onComplete: (taskId: string) => void;
}) {
  const difficulty = getDifficultyLabel(task.difficulty);
  const isCompleted = task.status === 'completed';

  return (
    <Card
      className={`border-0 transition-smooth transform hover:scale-[1.02] hover:shadow-lg cursor-pointer backdrop-blur-sm ${
        isCompleted 
          ? 'bg-gradient-to-r from-muted/30 to-muted/20 opacity-70' 
          : 'bg-white/50 dark:bg-slate-950/50 hover:bg-white/60 dark:hover:bg-slate-950/60'
      } animate-fadeInUp`}
      onClick={() => !isCompleted && onComplete(task.id)}
    >
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className="mt-1">
            <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-smooth ${
              isCompleted 
                ? 'bg-gradient-to-r from-primary to-accent border-primary' 
                : 'border-border hover:border-primary'
            }`}>
              {isCompleted && <span className="text-white text-xs">✓</span>}
            </div>
          </div>
          <div className="flex-1 space-y-3">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <h3
                className={`font-semibold text-base leading-tight transition-smooth ${
                  isCompleted
                    ? 'line-through text-muted-foreground'
                    : 'text-foreground'
                }`}
              >
                {task.title}
              </h3>
              <Badge className={`${categoryColors[task.category]} font-medium`}>
                {task.category}
              </Badge>
            </div>
            <p className={`text-sm transition-smooth ${isCompleted ? 'text-muted-foreground/60' : 'text-muted-foreground'}`}>
              {task.description}
            </p>

            <div className="flex flex-wrap gap-2">
              {task.skills.map((skill) => (
                <Badge key={skill} variant="outline" className="text-xs transition-smooth hover:bg-primary/10">
                  {skill}
                </Badge>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 text-xs border-t border-border/30">
              <div className="flex gap-6 mt-2 font-medium">
                <span className="flex items-center gap-1">
                  <span className="text-muted-foreground">Difficulty:</span>
                  <span className={`font-semibold ${difficulty.color}`}>
                    {difficulty.label}
                  </span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="text-muted-foreground">⏱️</span>
                  <span className="font-medium">{task.estimatedHours}h</span>
                </span>
              </div>
              <span className="text-muted-foreground text-xs">
                {task.difficulty}/10
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function RoadmapView({ roadmap, onTaskComplete }: RoadmapViewProps) {
  // Group tasks by phase
  const totalTasks = roadmap.tasks.length;
  const completedTasks = roadmap.tasks.filter(
    (t) => t.status === 'completed'
  ).length;

  const phaseBreakpoints = [
    Math.ceil(totalTasks * 0.25),
    Math.ceil(totalTasks * 0.5),
    Math.ceil(totalTasks * 0.75),
  ];

  const phases = [
    { name: 'foundation', start: 0, end: phaseBreakpoints[0] },
    { name: 'growth', start: phaseBreakpoints[0], end: phaseBreakpoints[1] },
    { name: 'mastery', start: phaseBreakpoints[1], end: phaseBreakpoints[2] },
    { name: 'leadership', start: phaseBreakpoints[2], end: totalTasks },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Your Career Roadmap</CardTitle>
          <CardDescription>
            {completedTasks}/{totalTasks} tasks completed (
            {Math.round((completedTasks / totalTasks) * 100)}%)
          </CardDescription>
        </CardHeader>
      </Card>

      {phases.map((phase) => {
        const phaseTasks = roadmap.tasks.slice(phase.start, phase.end);
        if (phaseTasks.length === 0) return null;

        const phaseCompleted = phaseTasks.filter(
          (t) => t.status === 'completed'
        ).length;

        return (
          <div key={phase.name} className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {phaseNames[phase.name as keyof typeof phaseNames]}
              </h2>
              <span className="text-sm text-muted-foreground">
                {phaseCompleted}/{phaseTasks.length} completed
              </span>
            </div>

            <div className="w-full bg-secondary rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all"
                style={{
                  width: `${(phaseCompleted / phaseTasks.length) * 100}%`,
                }}
              />
            </div>

            <div className="space-y-3">
              {phaseTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onComplete={onTaskComplete}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
