'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { UserProfile, CareerRoadmap, ChatMessage } from '@/lib/types';
import { clientStorage } from '@/lib/storage';

interface ChatInterfaceProps {
  profile: UserProfile;
  roadmap: CareerRoadmap;
}

export function ChatInterface({ profile, roadmap }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    clientStorage.getMessages()
  );
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    clientStorage.addMessage(userMessage);
    setInput('');
    setIsLoading(true);

    try {
      // Call chat API
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          profile,
          roadmap,
        }),
      });

      const assistantMessage: ChatMessage = {
        id: `msg_${Date.now()}_assistant`,
        role: 'assistant',
        content: await response.text(),
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      clientStorage.addMessage(assistantMessage);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: ChatMessage = {
        id: `msg_${Date.now()}_error`,
        role: 'assistant',
        content:
          'Sorry, I encountered an error. Please try again.',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestedQuestions = [
    'What should I focus on next?',
    'How am I progressing towards my goal?',
    'What skills should I prioritize?',
    'How can I accelerate my learning?',
  ];

  const tasksCompleted = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = roadmap.tasks.length;
  const progressPercent = Math.round((tasksCompleted / totalTasks) * 100);

  return (
    <div className="space-y-4 h-full flex flex-col">
      <Card className="flex-1 flex flex-col border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 animate-fadeInUp">
        <CardHeader className="pb-4 border-b border-border/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <span className="text-white text-lg">🤖</span>
            </div>
            <div>
              <CardTitle className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">AI Career Coach</CardTitle>
              <CardDescription className="text-xs mt-0.5">
                Powered by real market data
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col gap-4">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
            {messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-8 space-y-4">
                <div className="text-4xl">💬</div>
                <p className="font-medium">Start a conversation with your AI coach</p>
                <p className="text-xs mb-4">Suggest a question below or ask your own</p>
                <div className="space-y-2">
                  {suggestedQuestions.map((q, idx) => (
                    <Button
                      key={q}
                      variant="outline"
                      size="sm"
                      onClick={() => setInput(q)}
                      className="w-full text-left justify-start transition-smooth hover:bg-primary/10 hover:border-primary animate-slideInLeft"
                      style={{ animationDelay: `${idx * 0.1}s` }}
                    >
                      <span className="text-xs">→</span> {q}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 animate-slideInLeft ${
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white text-xs">🤖</span>
                    </div>
                  )}
                  <div
                    className={`max-w-xs px-4 py-3 rounded-lg transition-smooth ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-primary to-accent text-white rounded-br-none'
                        : 'bg-secondary/50 text-secondary-foreground rounded-bl-none border border-border/30'
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.content}</p>
                    <p className={`text-xs opacity-60 mt-1 ${msg.role === 'user' ? 'text-white/80' : ''}`}>
                      {msg.timestamp.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-xs">👤</span>
                    </div>
                  )}
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start gap-3 animate-slideInLeft">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs">🤖</span>
                </div>
                <div className="bg-secondary/50 text-secondary-foreground px-4 py-3 rounded-lg rounded-bl-none border border-border/30">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <form onSubmit={handleSendMessage} className="flex gap-2 pt-2 border-t border-border/30">
            <Input
              placeholder="Ask about your career..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading}
              className="transition-smooth border-border/50 focus:border-primary h-10"
            />
            <Button 
              type="submit" 
              disabled={isLoading || !input.trim()} 
              className="bg-gradient-to-r from-primary to-accent text-white font-medium transition-smooth hover:shadow-lg"
            >
              {isLoading ? '⏳' : '→'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-r from-primary/10 to-accent/10 animate-slideInRight">
        <CardContent className="pt-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {tasksCompleted}
              </div>
              <p className="text-xs text-muted-foreground font-medium">Tasks Done</p>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                {profile.currentSkills.length}
              </div>
              <p className="text-xs text-muted-foreground font-medium">Skills</p>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {progressPercent}%
              </div>
              <p className="text-xs text-muted-foreground font-medium">Progress</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-border/30">
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500" style={{ width: `${progressPercent}%` }}></div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
