'use client';

import { CareerRoadmap } from '@/lib/types';

interface PhaseTimelineProps {
  roadmap: CareerRoadmap;
}

export function PhaseTimeline({ roadmap }: PhaseTimelineProps) {
  const phases = [
    { id: 'foundation', name: 'Foundation', emoji: '🔨', duration: '0-6 months', color: 'from-blue-500 to-blue-600' },
    { id: 'growth', name: 'Growth', emoji: '📈', duration: '6-12 months', color: 'from-purple-500 to-purple-600' },
    { id: 'mastery', name: 'Mastery', emoji: '⭐', duration: '12-18 months', color: 'from-orange-500 to-orange-600' },
    { id: 'leadership', name: 'Leadership', emoji: '👑', duration: '18+ months', color: 'from-red-500 to-red-600' },
  ];

  const currentPhaseIndex = phases.findIndex((p) => p.id === roadmap.phase);

  return (
    <div className="w-full py-6">
      <div className="relative">
        {/* Background line */}
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-muted via-primary/20 to-muted -translate-y-1/2" />

        {/* Timeline items */}
        <div className="flex justify-between relative z-10">
          {phases.map((phase, idx) => {
            const isCompleted = idx < currentPhaseIndex;
            const isCurrent = idx === currentPhaseIndex;
            const isPending = idx > currentPhaseIndex;

            return (
              <div key={phase.id} className="flex flex-col items-center gap-3 flex-1">
                {/* Circle */}
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl font-bold transition-all duration-300 hover:scale-110 ${
                    isCurrent
                      ? 'bg-gradient-to-br ' + phase.color + ' text-white ring-4 ring-white dark:ring-slate-950 shadow-lg animate-pulse'
                      : isCompleted
                        ? 'bg-gradient-to-br from-green-400 to-green-500 text-white shadow-md'
                        : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {isCurrent && <span className="animate-bounce">{phase.emoji}</span>}
                  {isCompleted && <span>✓</span>}
                  {isPending && phase.emoji}
                </div>

                {/* Label */}
                <div className="text-center">
                  <p className={`font-semibold text-sm ${isCurrent ? 'text-primary' : isCompleted ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
                    {phase.name}
                  </p>
                  <p className="text-xs text-muted-foreground">{phase.duration}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
