'use client';

import { useState } from 'react';
import { CareerRoadmap, RoadmapTask } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RoadmapStats } from './roadmap-stats';
import { PhaseTimeline } from './phase-timeline';

interface DetailedRoadmapProps {
  roadmap: CareerRoadmap;
  onTaskComplete: (taskId: string) => void;
}

const phaseIcons = {
  foundation: '🔨',
  growth: '📈',
  mastery: '⭐',
  leadership: '👑',
};

const phaseDescriptions = {
  foundation: 'Build core skills and understanding. Focus on fundamentals and foundational knowledge.',
  growth: 'Expand expertise and take on more complex projects. Develop specialized skills.',
  mastery: 'Become an expert in your domain. Lead projects and mentor others.',
  leadership: 'Strategic thinking and organizational impact. Build teams and influence.',
};

const categoryData = {
  skill: { icon: '⚡', label: 'Skill', color: 'from-blue-500 to-cyan-500' },
  project: { icon: '🛠️', label: 'Project', color: 'from-purple-500 to-pink-500' },
  learning: { icon: '📚', label: 'Learning', color: 'from-green-500 to-emerald-500' },
  networking: { icon: '🤝', label: 'Networking', color: 'from-orange-500 to-yellow-500' },
};

function getDifficultyLabel(difficulty: number) {
  if (difficulty <= 3) return { label: 'Easy', icon: '🟢', color: 'text-green-600' };
  if (difficulty <= 6) return { label: 'Medium', icon: '🟡', color: 'text-yellow-600' };
  return { label: 'Hard', icon: '🔴', color: 'text-red-600' };
}

function TaskDetailModal({
  task,
  isOpen,
  onClose,
  onComplete,
}: {
  task: RoadmapTask;
  isOpen: boolean;
  onClose: () => void;
  onComplete: (taskId: string) => void;
}) {
  if (!isOpen) return null;

  const difficulty = getDifficultyLabel(task.difficulty);
  const isCompleted = task.status === 'completed';

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeInUp">
      <Card className="w-full max-w-2xl border-0 shadow-2xl bg-gradient-to-br from-white to-secondary/20 dark:from-slate-950 dark:to-slate-900/50 animate-scaleIn">
        <CardHeader className="border-b border-border/30 pb-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-3xl">{categoryData[task.category].icon}</span>
                <Badge className={`bg-gradient-to-r ${categoryData[task.category].color} text-white`}>
                  {categoryData[task.category].label}
                </Badge>
              </div>
              <CardTitle className="text-3xl bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {task.title}
              </CardTitle>
              <CardDescription className="text-base">{task.description}</CardDescription>
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-smooth text-2xl">
              ✕
            </button>
          </div>
        </CardHeader>

        <CardContent className="pt-8 space-y-8">
          {/* Difficulty & Time */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5">
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Difficulty</p>
              <div className="flex items-center gap-2">
                <span className={`text-3xl ${difficulty.color}`}>{difficulty.icon}</span>
                <div>
                  <p className="text-2xl font-bold">{difficulty.label}</p>
                  <p className="text-sm text-muted-foreground">{task.difficulty}/10</p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-gradient-to-br from-accent/10 to-accent/5">
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Time Estimate</p>
              <div className="flex items-center gap-2">
                <span className="text-3xl">⏱️</span>
                <div>
                  <p className="text-2xl font-bold">{task.estimatedHours}h</p>
                  <p className="text-sm text-muted-foreground">hours</p>
                </div>
              </div>
            </div>

            <div className={`p-4 rounded-lg bg-gradient-to-br ${isCompleted ? 'from-green-500/10 to-green-500/5' : 'from-orange-500/10 to-orange-500/5'}`}>
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Status</p>
              <div className="flex items-center gap-2">
                <span className="text-3xl">{isCompleted ? '✅' : '⏳'}</span>
                <div>
                  <p className="text-2xl font-bold capitalize">{task.status.replace('-', ' ')}</p>
                  <p className="text-sm text-muted-foreground">{isCompleted ? 'Completed' : 'In Progress'}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Skills */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-foreground uppercase tracking-wide">Skills to Develop</p>
            <div className="flex flex-wrap gap-2">
              {task.skills.map((skill) => (
                <Badge key={skill} variant="outline" className="px-3 py-1.5 text-sm transition-smooth hover:bg-primary/20">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>

          {/* Resources & Tips */}
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 p-4 rounded-lg border border-border/30">
            <p className="text-sm font-semibold text-foreground mb-3">Recommended Approach</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex gap-2">
                <span>→</span>
                <span>Break this task into smaller sub-tasks for better progress tracking</span>
              </li>
              <li className="flex gap-2">
                <span>→</span>
                <span>Complete related projects first to build foundational understanding</span>
              </li>
              <li className="flex gap-2">
                <span>→</span>
                <span>Use online resources and communities relevant to {task.skills.slice(0, 2).join(' and ')}</span>
              </li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t border-border/30">
            <Button
              onClick={() => {
                onComplete(task.id);
                onClose();
              }}
              disabled={isCompleted}
              className={`flex-1 ${
                isCompleted
                  ? 'bg-muted text-muted-foreground'
                  : 'bg-gradient-to-r from-primary to-accent text-white hover:shadow-lg'
              } font-semibold h-11 transition-smooth`}
            >
              {isCompleted ? '✓ Completed' : 'Mark as Complete'}
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1 h-11">
              Close
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function PhaseCard({
  phase,
  tasks,
  isCurrentPhase,
  onTaskComplete,
  onTaskDetail,
}: {
  phase: keyof typeof phaseIcons;
  tasks: RoadmapTask[];
  isCurrentPhase: boolean;
  onTaskComplete: (taskId: string) => void;
  onTaskDetail: (task: RoadmapTask) => void;
}) {
  const completedCount = tasks.filter((t) => t.status === 'completed').length;
  const completionPercent = Math.round((completedCount / tasks.length) * 100);

  return (
    <Card className={`border-0 shadow-lg backdrop-blur-sm transition-smooth hover:shadow-xl ${
      isCurrentPhase
        ? 'ring-2 ring-primary/50 bg-gradient-to-br from-primary/10 to-accent/10'
        : 'bg-white/50 dark:bg-slate-950/50'
    }`}>
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{phaseIcons[phase]}</span>
            <div>
              <CardTitle className="capitalize text-2xl">{phase}</CardTitle>
              <CardDescription className="text-xs mt-1">{phaseDescriptions[phase]}</CardDescription>
            </div>
          </div>
          {isCurrentPhase && <Badge className="bg-gradient-to-r from-primary to-accent text-white">Current</Badge>}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-semibold text-foreground">Progress</span>
            <span className="text-accent font-bold">{completedCount}/{tasks.length} tasks</span>
          </div>
          <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
              style={{ width: `${completionPercent}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground">{completionPercent}% Complete</p>
        </div>

        {/* Task List */}
        <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar">
          {tasks.map((task) => (
            <button
              key={task.id}
              onClick={() => onTaskDetail(task)}
              className="w-full text-left p-3 rounded-lg border border-border/30 bg-white/30 dark:bg-slate-900/30 hover:bg-white/60 dark:hover:bg-slate-900/60 transition-smooth group"
            >
              <div className="flex items-start gap-3">
                <Checkbox
                  checked={task.status === 'completed'}
                  onCheckedChange={() => onTaskComplete(task.id)}
                  onClick={(e) => e.stopPropagation()}
                  className="mt-1"
                />
                <div className="flex-1 min-w-0">
                  <p
                    className={`font-medium text-sm transition-smooth ${
                      task.status === 'completed'
                        ? 'line-through text-muted-foreground'
                        : 'text-foreground group-hover:text-primary'
                    }`}
                  >
                    {task.title}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{task.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">
                      {getDifficultyLabel(task.difficulty).icon} {getDifficultyLabel(task.difficulty).label}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-accent/20 text-accent">⏱️ {task.estimatedHours}h</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="pt-3 border-t border-border/30 grid grid-cols-3 gap-2 text-center">
          <div className="space-y-1">
            <p className="text-2xl font-bold text-primary">{completedCount}</p>
            <p className="text-xs text-muted-foreground">Done</p>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-accent">{tasks.filter((t) => t.status === 'in-progress').length}</p>
            <p className="text-xs text-muted-foreground">Active</p>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-muted-foreground">{tasks.filter((t) => t.status === 'pending').length}</p>
            <p className="text-xs text-muted-foreground">Pending</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function DetailedRoadmap({ roadmap, onTaskComplete }: DetailedRoadmapProps) {
  const [selectedTask, setSelectedTask] = useState<RoadmapTask | null>(null);
  const phases = ['foundation', 'growth', 'mastery', 'leadership'] as const;
  const tasksPerPhase = {
    foundation: roadmap.tasks.filter((t) => t.difficulty <= 3),
    growth: roadmap.tasks.filter((t) => t.difficulty > 3 && t.difficulty <= 6),
    mastery: roadmap.tasks.filter((t) => t.difficulty > 6 && t.difficulty <= 8),
    leadership: roadmap.tasks.filter((t) => t.difficulty > 8),
  };

  const totalCompleted = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = roadmap.tasks.length;
  const overallProgress = Math.round((totalCompleted / totalTasks) * 100);

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <RoadmapStats roadmap={roadmap} />

      {/* Phase Timeline */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 animate-fadeInUp">
        <CardContent className="pt-8">
          <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <span className="text-2xl">📍</span>
            Career Progression Timeline
          </h3>
          <PhaseTimeline roadmap={roadmap} />
        </CardContent>
      </Card>

      {/* Header Overview */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-r from-primary/10 via-accent/10 to-primary/5 animate-fadeInUp">
        <CardContent className="pt-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-2 text-center">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total Progress</p>
              <div className="text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {overallProgress}%
              </div>
              <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
                  style={{ width: `${overallProgress}%` }}
                />
              </div>
            </div>

            <div className="space-y-2 text-center">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Tasks Done</p>
              <p className="text-5xl font-bold text-primary">{totalCompleted}</p>
              <p className="text-sm text-muted-foreground">of {totalTasks} tasks</p>
            </div>

            <div className="space-y-2 text-center">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total Time</p>
              <p className="text-5xl font-bold text-accent">
                {Math.round(roadmap.tasks.reduce((sum, t) => sum + t.estimatedHours, 0))}h
              </p>
              <p className="text-sm text-muted-foreground">investment needed</p>
            </div>

            <div className="space-y-2 text-center">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Current Phase</p>
              <p className="text-3xl">{phaseIcons[roadmap.phase]}</p>
              <p className="text-sm font-semibold text-foreground capitalize">{roadmap.phase}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline Phases */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Your Career Path</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {phases.map((phase, idx) => (
            <div key={phase} className="animate-slideInLeft" style={{ animationDelay: `${idx * 0.1}s` }}>
              <PhaseCard
                phase={phase}
                tasks={tasksPerPhase[phase]}
                isCurrentPhase={roadmap.phase === phase}
                onTaskComplete={onTaskComplete}
                onTaskDetail={setSelectedTask}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Category Breakdown */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 animate-slideInLeft">
        <CardHeader className="pb-4 border-b border-border/30">
          <CardTitle className="flex items-center gap-2">
            <span className="text-2xl">📊</span>
            Task Distribution by Category
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(categoryData).map(([category, data]) => {
              const count = roadmap.tasks.filter((t) => t.category === category).length;
              const completed = roadmap.tasks.filter((t) => t.category === category && t.status === 'completed').length;
              return (
                <div
                  key={category}
                  className="p-4 rounded-lg bg-gradient-to-br from-white/50 to-white/20 dark:from-slate-900/50 dark:to-slate-900/20 border border-border/30 hover:shadow-md transition-smooth"
                >
                  <p className="text-2xl mb-2">{data.icon}</p>
                  <p className="font-semibold text-sm text-foreground">{data.label}</p>
                  <p className="text-2xl font-bold mt-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {count}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{completed} completed</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          isOpen={!!selectedTask}
          onClose={() => setSelectedTask(null)}
          onComplete={onTaskComplete}
        />
      )}
    </div>
  );
}
