'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CareerRoadmap } from '@/lib/types';
import { runEvolution } from '@/lib/agents/evolution';

interface ProgressTrackerProps {
  roadmap: CareerRoadmap;
}

export function ProgressTracker({ roadmap }: ProgressTrackerProps) {
  const [evolutionReport, setEvolutionReport] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const evaluateRoadmap = async () => {
      try {
        // Calculate weeks since last evaluation
        const weeksSince = Math.max(
          1,
          Math.floor(
            (new Date().getTime() - roadmap.lastEvaluatedAt.getTime()) /
              (7 * 24 * 60 * 60 * 1000)
          )
        );

        // Mock GitHub activity for demo
        const mockGitHubActivity = {
          username: 'user',
          lastFetched: new Date(),
          commitCount: 45,
          recentProjects: [],
          contributions: {
            thisWeek: 15,
            thisMonth: 45,
            total: 234,
          },
        };

        const result = await runEvolution({
          roadmap,
          githubActivity: mockGitHubActivity,
          weeksSinceLastEvaluation: weeksSince,
        });

        setEvolutionReport(result.evaluationReport);
      } catch (error) {
        console.error('Error evaluating roadmap:', error);
      } finally {
        setIsLoading(false);
      }
    };

    evaluateRoadmap();
  }, [roadmap]);

  const totalTasks = roadmap.tasks.length;
  const completedTasks = roadmap.tasks.filter(
    (t) => t.status === 'completed'
  ).length;
  const inProgressTasks = roadmap.tasks.filter(
    (t) => t.status === 'in-progress'
  ).length;
  const pendingTasks = roadmap.tasks.filter(
    (t) => t.status === 'pending'
  ).length;

  const totalHours = roadmap.tasks.reduce((sum, t) => sum + t.estimatedHours, 0);
  const completedHours = roadmap.tasks
    .filter((t) => t.status === 'completed')
    .reduce((sum, t) => sum + t.estimatedHours, 0);

  const completionPercent = Math.round((completedTasks / totalTasks) * 100);

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-primary/20 to-primary/5 hover:shadow-xl transition-smooth animate-slideInLeft">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{completedTasks}</div>
              <p className="text-xs text-muted-foreground font-medium">Tasks Done</p>
              <div className="text-xs text-primary font-semibold">✓ Complete</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-accent/20 to-accent/5 hover:shadow-xl transition-smooth animate-slideInLeft" style={{ animationDelay: '0.05s' }}>
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">{inProgressTasks}</div>
              <p className="text-xs text-muted-foreground font-medium">In Progress</p>
              <div className="text-xs text-accent font-semibold">⟳ Active</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-primary/20 to-primary/5 hover:shadow-xl transition-smooth animate-slideInRight">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {completionPercent}%
              </div>
              <p className="text-xs text-muted-foreground font-medium">Progress</p>
              <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mt-2">
                <div className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500" style={{ width: `${completionPercent}%` }}></div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-accent/20 to-accent/5 hover:shadow-xl transition-smooth animate-slideInRight" style={{ animationDelay: '0.05s' }}>
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                {Math.round(completedHours)}h
              </div>
              <p className="text-xs text-muted-foreground font-medium">Time Invested</p>
              <div className="text-xs text-accent font-semibold">⏱️ {totalHours}h total</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Evolution Report */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 animate-fadeInUp">
        <CardHeader className="pb-4 border-b border-border/30">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📈</span>
            <div>
              <CardTitle className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Evolution Analysis</CardTitle>
              <CardDescription className="text-xs mt-1">AI-powered roadmap re-evaluation</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8 space-x-3">
              <div className="animate-pulseSoft">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
              </div>
              <p className="text-muted-foreground font-medium">Analyzing your progress...</p>
            </div>
          ) : (
            <div className="bg-gradient-to-br from-secondary/50 to-secondary/20 p-4 rounded-lg border border-border/30 overflow-auto max-h-96 font-mono text-xs space-y-2 text-foreground leading-relaxed">
              {evolutionReport.split('\n').map((line, idx) => (
                <div key={idx} className="animate-fadeInUp" style={{ animationDelay: `${(idx % 5) * 0.05}s` }}>
                  {line}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Time Investment */}
      <Card className="border-0 shadow-lg backdrop-blur-sm bg-gradient-to-br from-primary/10 to-accent/10 animate-slideInLeft">
        <CardHeader className="pb-4 border-b border-border/30">
          <div className="flex items-center gap-2">
            <span className="text-2xl">⏱️</span>
            <CardTitle className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Time Investment</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '0s' }}>
            <div className="flex justify-between text-sm mb-3">
              <span className="font-medium">Total Planned Hours</span>
              <span className="font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent text-base">{totalHours}h</span>
            </div>
            <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-primary/20 to-accent/20" style={{ width: '100%' }} />
            </div>
          </div>

          <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '0.1s' }}>
            <div className="flex justify-between text-sm mb-3">
              <span className="font-medium">Completed</span>
              <span className="font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent text-base">
                {completedHours}h · {Math.round((completedHours / totalHours) * 100)}%
              </span>
            </div>
            <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
                style={{ width: `${(completedHours / totalHours) * 100}%` }}
              />
            </div>
          </div>

          <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '0.2s' }}>
            <div className="flex justify-between text-sm mb-3">
              <span className="font-medium">Remaining</span>
              <span className="font-bold text-muted-foreground text-base">{totalHours - completedHours}h</span>
            </div>
            <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-muted-foreground/50"
                style={{
                  width: `${((totalHours - completedHours) / totalHours) * 100}%`,
                }}
              />
            </div>
          </div>

          <div className="pt-4 border-t border-border/30 grid grid-cols-3 gap-4 text-center">
            <div className="space-y-1">
              <p className="text-2xl font-bold text-primary">{Math.round((completedHours / totalHours) * 100)}%</p>
              <p className="text-xs text-muted-foreground font-medium">Completed</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-accent">{pendingTasks}</p>
              <p className="text-xs text-muted-foreground font-medium">Pending</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-bold text-primary">{totalHours - completedHours}h</p>
              <p className="text-xs text-muted-foreground font-medium">To Go</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
