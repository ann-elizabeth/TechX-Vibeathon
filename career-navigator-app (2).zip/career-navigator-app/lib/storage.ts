import {
  UserProfile,
  CareerRoadmap,
  RoadmapTask,
  GitHubActivity,
  ChatMessage,
  SessionState,
  AgentMetrics,
} from './types';

const STORAGE_KEYS = {
  PROFILE: 'career_navigator_profile',
  ROADMAP: 'career_navigator_roadmap',
  MESSAGES: 'career_navigator_messages',
  GITHUB_ACTIVITY: 'career_navigator_github_activity',
  AGENT_METRICS: 'career_navigator_agent_metrics',
  SESSION: 'career_navigator_session',
};

/**
 * LocalStorage wrapper for server-side compatible operations
 * Use in API routes and server actions only
 */
class StorageManager {
  private data: Map<string, unknown> = new Map();
  private isInitialized = false;

  private initializeData() {
    if (this.isInitialized) return;

    // Initialize default data
    this.data.set(STORAGE_KEYS.PROFILE, null);
    this.data.set(STORAGE_KEYS.ROADMAP, null);
    this.data.set(STORAGE_KEYS.MESSAGES, []);
    this.data.set(STORAGE_KEYS.GITHUB_ACTIVITY, null);
    this.data.set(STORAGE_KEYS.AGENT_METRICS, {
      goalsSet: 0,
      tasksDecomposed: 0,
      completedTasks: 0,
      evolutionEvaluations: 0,
      lastEvaluationTime: new Date(),
    });
    this.data.set(STORAGE_KEYS.SESSION, null);

    this.isInitialized = true;
  }

  // Profile operations
  saveProfile(profile: UserProfile) {
    this.initializeData();
    this.data.set(STORAGE_KEYS.PROFILE, profile);
  }

  getProfile(): UserProfile | null {
    this.initializeData();
    return (this.data.get(STORAGE_KEYS.PROFILE) as UserProfile) || null;
  }

  // Roadmap operations
  saveRoadmap(roadmap: CareerRoadmap) {
    this.initializeData();
    this.data.set(STORAGE_KEYS.ROADMAP, roadmap);
  }

  getRoadmap(): CareerRoadmap | null {
    this.initializeData();
    return (this.data.get(STORAGE_KEYS.ROADMAP) as CareerRoadmap) || null;
  }

  updateTaskStatus(taskId: string, status: RoadmapTask['status']) {
    const roadmap = this.getRoadmap();
    if (!roadmap) return;

    const task = roadmap.tasks.find((t) => t.id === taskId);
    if (task) {
      task.status = status;
      if (status === 'completed') {
        task.completedAt = new Date();
      }
      task.updatedAt = new Date();
      this.saveRoadmap(roadmap);
    }
  }

  // Messages operations
  addMessage(message: ChatMessage) {
    this.initializeData();
    const messages = (this.data.get(STORAGE_KEYS.MESSAGES) as ChatMessage[]) || [];
    messages.push(message);
    this.data.set(STORAGE_KEYS.MESSAGES, messages);
  }

  getMessages(): ChatMessage[] {
    this.initializeData();
    return (this.data.get(STORAGE_KEYS.MESSAGES) as ChatMessage[]) || [];
  }

  clearMessages() {
    this.initializeData();
    this.data.set(STORAGE_KEYS.MESSAGES, []);
  }

  // GitHub activity operations
  saveGitHubActivity(activity: GitHubActivity) {
    this.initializeData();
    this.data.set(STORAGE_KEYS.GITHUB_ACTIVITY, activity);
  }

  getGitHubActivity(): GitHubActivity | null {
    this.initializeData();
    return (this.data.get(STORAGE_KEYS.GITHUB_ACTIVITY) as GitHubActivity) || null;
  }

  // Agent metrics operations
  getAgentMetrics(): AgentMetrics {
    this.initializeData();
    return (
      (this.data.get(STORAGE_KEYS.AGENT_METRICS) as AgentMetrics) || {
        goalsSet: 0,
        tasksDecomposed: 0,
        completedTasks: 0,
        evolutionEvaluations: 0,
        lastEvaluationTime: new Date(),
      }
    );
  }

  incrementMetric(metric: keyof Omit<AgentMetrics, 'lastEvaluationTime'>) {
    const metrics = this.getAgentMetrics();
    metrics[metric] = (metrics[metric] as number) + 1;
    metrics.lastEvaluationTime = new Date();
    this.data.set(STORAGE_KEYS.AGENT_METRICS, metrics);
  }

  // Session operations
  saveSession(session: SessionState) {
    this.initializeData();
    this.data.set(STORAGE_KEYS.SESSION, session);
  }

  getSession(): SessionState | null {
    this.initializeData();
    return (this.data.get(STORAGE_KEYS.SESSION) as SessionState) || null;
  }

  // Utility
  clear() {
    this.data.clear();
    this.isInitialized = false;
  }
}

export const storage = new StorageManager();

/**
 * Browser-side localStorage wrapper
 * Use in Client Components only
 */
export const clientStorage = {
  saveProfile: (profile: UserProfile) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    }
  },

  getProfile: (): UserProfile | null => {
    if (typeof window !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : null;
    }
    return null;
  },

  saveRoadmap: (roadmap: CareerRoadmap) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.ROADMAP, JSON.stringify(roadmap));
    }
  },

  getRoadmap: (): CareerRoadmap | null => {
    if (typeof window !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEYS.ROADMAP);
      return data ? JSON.parse(data) : null;
    }
    return null;
  },

  addMessage: (message: ChatMessage) => {
    if (typeof window !== 'undefined') {
      const messages = clientStorage.getMessages();
      messages.push(message);
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    }
  },

  getMessages: (): ChatMessage[] => {
    if (typeof window !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      return data ? JSON.parse(data) : [];
    }
    return [];
  },

  clearMessages: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEYS.MESSAGES);
    }
  },

  saveSession: (session: SessionState) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
    }
  },

  getSession: (): SessionState | null => {
    if (typeof window !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEYS.SESSION);
      return data ? JSON.parse(data) : null;
    }
    return null;
  },

  clear: () => {
    if (typeof window !== 'undefined') {
      Object.values(STORAGE_KEYS).forEach((key) => {
        localStorage.removeItem(key);
      });
    }
  },
};
