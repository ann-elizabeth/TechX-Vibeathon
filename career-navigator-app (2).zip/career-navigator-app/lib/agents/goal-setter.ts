import { UserProfile, CareerRoadmap, RoadmapTask } from '../types';
import { getSkillsByDemand, recommendSkillsForUser } from '../skill-engine';

/**
 * Goal Setter Agent
 * Analyzes user profile and sets strategic career goals
 * Outputs: Career goal statement, target role, timeline
 */
export interface GoalSetterInput {
  currentRole: string;
  currentSkills: string[];
  yearsOfExperience: number;
  careerAspirations: string;
  constraints?: string; // e.g., "need flexible schedule", "want remote work"
}

export interface GoalSetterOutput {
  primaryGoal: string;
  targetRole: string;
  targetSalaryRange: { min: number; max: number };
  timelineMonths: number;
  reasoning: string;
  nextSteps: string[];
}

export async function runGoalSetter(input: GoalSetterInput): Promise<GoalSetterOutput> {
  // Analyze current position and market trends
  const topSkills = getSkillsByDemand(5);
  const recommendedSkills = recommendSkillsForUser(input.currentSkills, 5);

  // Determine progression level
  const progressionLevels = {
    junior: { nextLevel: 'mid', timelineMonths: 12 },
    mid: { nextLevel: 'senior', timelineMonths: 18 },
    senior: { nextLevel: 'lead', timelineMonths: 24 },
  };

  // Estimate current level based on experience
  let currentLevel: 'junior' | 'mid' | 'senior' = 'junior';
  if (input.yearsOfExperience > 5) currentLevel = 'mid';
  if (input.yearsOfExperience > 10) currentLevel = 'senior';

  const progression = progressionLevels[currentLevel];

  // Calculate target salary based on market data
  const avgHighDemandSalary =
    topSkills.reduce((sum, skill) => sum + skill.avgSalary, 0) / topSkills.length;
  const targetSalaryMin = Math.round(avgHighDemandSalary * 0.85);
  const targetSalaryMax = Math.round(avgHighDemandSalary * 1.15);

  // Build goal statement
  const primaryGoal = `Advance from ${currentLevel}-level ${input.currentRole} to ${progression.nextLevel}-level engineer with expertise in ${recommendedSkills[0]?.skill || 'emerging technologies'}, increasing earning potential to $${targetSalaryMin.toLocaleString()}-$${targetSalaryMax.toLocaleString()}`;

  const targetRole = `${progression.nextLevel.charAt(0).toUpperCase() + progression.nextLevel.slice(1)}-Level ${input.currentRole.split(' ')[0]}`;

  return {
    primaryGoal,
    targetRole,
    targetSalaryRange: {
      min: targetSalaryMin,
      max: targetSalaryMax,
    },
    timelineMonths: progression.timelineMonths,
    reasoning: `Based on ${input.yearsOfExperience} years of experience and current market demand, you're positioned for ${progression.nextLevel}-level advancement. Key skills in demand: ${recommendedSkills.slice(0, 3).map((s) => s.skill).join(', ')}.`,
    nextSteps: [
      `Master ${recommendedSkills[0]?.skill || 'key technologies'}`,
      'Build portfolio projects demonstrating new skills',
      'Network with engineers in target role',
      'Contribute to open source in target domain',
    ],
  };
}
