import { RoadmapTask } from '../types';
import { computeSkillFrequency } from '../skill-engine';

/**
 * Task Decomposer Agent
 * Breaks down career goals into actionable tasks
 * Outputs: Structured roadmap tasks with difficulty, time estimates, and skills
 */
export interface DecomposerInput {
  goal: string;
  targetRole: string;
  timelineMonths: number;
  requiredSkills: string[];
  currentSkills: string[];
}

export interface DecomposerOutput {
  phase1: RoadmapTask[]; // Foundation (0-6 months)
  phase2: RoadmapTask[]; // Growth (6-12 months)
  phase3: RoadmapTask[]; // Mastery (12-18 months)
  phase4: RoadmapTask[]; // Leadership (18+ months)
  reasoning: string;
}

function generateTaskId(): string {
  return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export async function runDecomposer(input: DecomposerInput): Promise<DecomposerOutput> {
  const skillMap = computeSkillFrequency();
  const skillsToLearn = input.requiredSkills.filter(
    (skill) => !input.currentSkills.includes(skill)
  );

  const tasks = {
    phase1: [] as RoadmapTask[],
    phase2: [] as RoadmapTask[],
    phase3: [] as RoadmapTask[],
    phase4: [] as RoadmapTask[],
  };

  // Phase 1: Foundation (Learn core skills)
  tasks.phase1 = skillsToLearn.slice(0, 2).map((skill, idx) => ({
    id: generateTaskId(),
    title: `Master ${skill} Fundamentals`,
    description: `Complete comprehensive course and build 2-3 projects in ${skill}`,
    category: 'skill' as const,
    difficulty: 3 + idx,
    estimatedHours: 80 + idx * 40,
    skills: [skill],
    status: 'pending' as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));

  // Add foundation projects
  tasks.phase1.push({
    id: generateTaskId(),
    title: 'Build Foundation Portfolio Project',
    description: 'Create 1-2 projects using newly learned core skills',
    category: 'project' as const,
    difficulty: 4,
    estimatedHours: 100,
    skills: skillsToLearn.slice(0, 2),
    status: 'pending' as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  // Phase 2: Growth (Deepen skills, start advanced topics)
  tasks.phase2 = skillsToLearn.slice(2, 4).map((skill, idx) => ({
    id: generateTaskId(),
    title: `Advanced ${skill} Mastery`,
    description: `Build production-grade applications and contribute to open source in ${skill}`,
    category: 'skill' as const,
    difficulty: 5 + idx,
    estimatedHours: 120 + idx * 40,
    skills: [skill],
    status: 'pending' as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));

  // Phase 2: System design and architecture
  tasks.phase2.push({
    id: generateTaskId(),
    title: 'System Design & Architecture',
    description: 'Learn scalable system design patterns and architectural principles',
    category: 'learning' as const,
    difficulty: 6,
    estimatedHours: 100,
    skills: ['System Design', 'Architecture', 'Scalability'],
    status: 'pending' as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  // Phase 2: Open source contributions
  tasks.phase2.push({
    id: generateTaskId(),
    title: 'Contribute to Major Open Source',
    description: 'Make meaningful contributions to 2-3 significant open source projects',
    category: 'project' as const,
    difficulty: 6,
    estimatedHours: 150,
    skills: ['Collaboration', 'Code Review', 'Best Practices'],
    status: 'pending' as const,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  // Phase 3: Mastery (Leadership, mentoring, specialized projects)
  tasks.phase3 = [
    {
      id: generateTaskId(),
      title: 'Lead Technical Project',
      description: 'Own and lead end-to-end technical project with team collaboration',
      category: 'project' as const,
      difficulty: 7,
      estimatedHours: 200,
      skills: ['Leadership', 'Project Management', ...skillsToLearn.slice(0, 2)],
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: generateTaskId(),
      title: 'Write Technical Articles & Documentation',
      description: 'Publish 3-5 technical articles demonstrating expertise',
      category: 'learning' as const,
      difficulty: 5,
      estimatedHours: 80,
      skills: ['Technical Writing', 'Communication'],
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: generateTaskId(),
      title: 'Build Signature Portfolio Piece',
      description: 'Create ambitious project that showcases all learned skills',
      category: 'project' as const,
      difficulty: 8,
      estimatedHours: 250,
      skills: skillsToLearn,
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  // Phase 4: Leadership (Mentoring, speaking, influence)
  tasks.phase4 = [
    {
      id: generateTaskId(),
      title: 'Mentor Junior Developers',
      description: 'Actively mentor 2-3 junior developers or create educational content',
      category: 'networking' as const,
      difficulty: 6,
      estimatedHours: 100,
      skills: ['Mentoring', 'Leadership', 'Communication'],
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: generateTaskId(),
      title: 'Speak at Technical Conferences',
      description: 'Present your work at 2+ tech conferences or meetups',
      category: 'networking' as const,
      difficulty: 6,
      estimatedHours: 120,
      skills: ['Public Speaking', 'Presentation', 'Thought Leadership'],
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: generateTaskId(),
      title: 'Lead Strategic Initiatives',
      description: 'Drive architectural decisions and technical strategy at organization level',
      category: 'project' as const,
      difficulty: 8,
      estimatedHours: 300,
      skills: ['Strategic Thinking', 'Architecture', 'Leadership'],
      status: 'pending' as const,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  return {
    phase1: tasks.phase1,
    phase2: tasks.phase2,
    phase3: tasks.phase3,
    phase4: tasks.phase4,
    reasoning: `Roadmap structured in 4 phases spanning ${input.timelineMonths} months. Phase 1 (Foundation): Master core ${skillsToLearn.slice(0, 2).join(', ')} with practical projects. Phase 2 (Growth): Advanced topics, open source, system design. Phase 3 (Mastery): Leadership, technical depth. Phase 4 (Leadership): Mentoring, influence, strategic impact.`,
  };
}
