import { CareerRoadmap, RoadmapTask, GitHubActivity } from '../types';
import { computeSkillFrequency } from '../skill-engine';

/**
 * Evolution Agent
 * Re-evaluates roadmap based on:
 * - Completed tasks
 * - GitHub activity
 * - Market skill demand changes
 * - Pace/velocity of progress
 *
 * Dynamically adjusts difficulty levels to keep user challenged but not overwhelmed
 */
export interface EvolutionInput {
  roadmap: CareerRoadmap;
  githubActivity?: GitHubActivity;
  weeksSinceLastEvaluation: number;
}

export interface EvolutionOutput {
  evaluationReport: string;
  adjustedTasks: RoadmapTask[];
  difficultyAdjustments: Array<{
    taskId: string;
    oldDifficulty: number;
    newDifficulty: number;
    reason: string;
  }>;
  recommendedFocus: string[];
  nextPhaseRecommendation?: string;
}

export async function runEvolution(input: EvolutionInput): Promise<EvolutionOutput> {
  const { roadmap, githubActivity, weeksSinceLastEvaluation } = input;

  // Calculate completion metrics
  const totalTasks = roadmap.tasks.length;
  const completedTasks = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const completionRate = (completedTasks / totalTasks) * 100;
  const weeklyCompletionRate = completedTasks / weeksSinceLastEvaluation;

  // Analyze GitHub activity for proof of progress
  let codeQualityScore = 50; // Base score
  if (githubActivity) {
    const weeklyCommits = githubActivity.contributions.thisWeek;
    const monthlyCommits = githubActivity.contributions.thisMonth;

    // High activity = good velocity
    if (monthlyCommits > 30) codeQualityScore += 25;
    else if (monthlyCommits > 15) codeQualityScore += 15;
    else codeQualityScore -= 10;
  }

  // Get current market skill demand for reallocation
  const skillMap = computeSkillFrequency();
  const topMarketSkills = Object.values(skillMap)
    .sort((a, b) => b.marketValue - a.marketValue)
    .slice(0, 10)
    .map((s) => s.skill);

  // Determine dynamic difficulty adjustments
  const difficultyAdjustments: Array<{
    taskId: string;
    oldDifficulty: number;
    newDifficulty: number;
    reason: string;
  }> = [];

  const adjustedTasks = roadmap.tasks.map((task) => {
    const adjustedTask = { ...task };
    let difficultyDelta = 0;
    let reason = '';

    // If completing tasks faster than expected, increase difficulty
    if (weeklyCompletionRate > 1 && task.status !== 'completed') {
      difficultyDelta = 2;
      reason = `High completion velocity (${weeklyCompletionRate.toFixed(1)} tasks/week) - increase challenge`;
    }
    // If slow progress, decrease difficulty
    else if (weeklyCompletionRate < 0.3 && task.status !== 'completed') {
      difficultyDelta = -2;
      reason = `Slower completion pace - reduce difficulty to maintain momentum`;
    }
    // If task relates to high-demand skills, keep/increase difficulty
    else if (
      task.skills.some(
        (s) =>
          topMarketSkills.includes(s) &&
          !roadmap.tasks
            .filter((t) => t.status === 'completed')
            .flatMap((t) => t.skills)
            .includes(s)
      )
    ) {
      difficultyDelta = 1;
      reason = `Related to high-market-demand skills - prioritize`;
    }

    if (difficultyDelta !== 0) {
      const oldDifficulty = adjustedTask.difficulty;
      adjustedTask.difficulty = Math.max(1, Math.min(10, oldDifficulty + difficultyDelta));

      difficultyAdjustments.push({
        taskId: task.id,
        oldDifficulty,
        newDifficulty: adjustedTask.difficulty,
        reason,
      });

      // Adjust estimated hours proportionally
      adjustedTask.estimatedHours = Math.round(
        task.estimatedHours * (adjustedTask.difficulty / oldDifficulty)
      );
    }

    return adjustedTask;
  });

  // Recommend focus areas
  const completedTaskSkills = new Set(
    roadmap.tasks
      .filter((t) => t.status === 'completed')
      .flatMap((t) => t.skills)
  );

  const recommendedFocus = topMarketSkills.filter(
    (skill) =>
      !completedTaskSkills.has(skill) &&
      roadmap.tasks.some(
        (t) => t.skills.includes(skill) && t.status !== 'completed'
      )
  );

  // Determine if user should advance to next phase
  let nextPhaseRecommendation: string | undefined;
  if (completionRate > 75) {
    nextPhaseRecommendation = `Excellent progress! You're ready to advance to the next phase. ${recommendedFocus.length > 0 ? `Focus on: ${recommendedFocus.slice(0, 3).join(', ')}` : ''}`;
  } else if (completionRate < 30) {
    nextPhaseRecommendation = `Current phase still has important fundamentals. Complete at least 50% before advancing.`;
  }

  const evaluationReport = `
Evolution Evaluation Report
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Completion Rate: ${completionRate.toFixed(0)}% (${completedTasks}/${totalTasks} tasks)
Weekly Completion Velocity: ${weeklyCompletionRate.toFixed(2)} tasks/week
Code Quality Score: ${codeQualityScore}/100
${githubActivity ? `GitHub Commits (Week): ${githubActivity.contributions.thisWeek}` : ''}

Market Demand Changes:
Top emerging skills: ${topMarketSkills.slice(0, 3).join(', ')}

Adjustments Made:
${difficultyAdjustments.length > 0 ? difficultyAdjustments.map((a) => `• ${a.taskId}: difficulty ${a.oldDifficulty}→${a.newDifficulty} (${a.reason})`).join('\n') : 'No adjustments needed'}

Recommendation: ${nextPhaseRecommendation || 'Continue current pace - maintain momentum!'}
  `.trim();

  return {
    evaluationReport,
    adjustedTasks,
    difficultyAdjustments,
    recommendedFocus: recommendedFocus.slice(0, 5),
    nextPhaseRecommendation,
  };
}
