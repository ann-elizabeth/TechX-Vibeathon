export interface UserProfile {
  id: string;
  name: string;
  currentRole: string;
  currentSkills: string[];
  careerGoal: string;
  yearsOfExperience: number;
  targetRole?: string;
  targetSalary?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface RoadmapTask {
  id: string;
  title: string;
  description: string;
  category: 'skill' | 'project' | 'learning' | 'networking';
  difficulty: number; // 1-10
  estimatedHours: number;
  status: 'pending' | 'in-progress' | 'completed';
  skills: string[];
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface CareerRoadmap {
  id: string;
  userId: string;
  goal: string;
  phase: 'foundation' | 'growth' | 'mastery' | 'leadership';
  tasks: RoadmapTask[];
  currentPhaseIndex: number;
  completionRate: number; // 0-100
  lastEvaluatedAt: Date;
  nextEvaluationAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface GitHubActivity {
  username: string;
  lastFetched: Date;
  commitCount: number;
  recentProjects: Array<{
    name: string;
    url: string;
    language: string;
    stars: number;
  }>;
  contributions: {
    thisWeek: number;
    thisMonth: number;
    total: number;
  };
}

export interface AgentMetrics {
  goalsSet: number;
  tasksDecomposed: number;
  completedTasks: number;
  evolutionEvaluations: number;
  lastEvaluationTime: Date;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  agentContext?: {
    agentType: 'goal-setter' | 'decomposer' | 'evolution' | 'none';
    metadata: Record<string, unknown>;
  };
}

export interface SessionState {
  userId: string;
  currentPhase: 'onboarding' | 'chatting' | 'viewing-roadmap' | 'tracking-progress';
  profile?: UserProfile;
  roadmap?: CareerRoadmap;
  messages: ChatMessage[];
  lastActivity: Date;
}
