import jobData from './datasets/linkedin-jobs.json';

export interface SkillMetrics {
  skill: string;
  frequency: number;
  avgSalary: number;
  requiredCount: number;
  niceToHaveCount: number;
  demandScore: number;
  marketValue: number;
}

export interface SkillFrequencyMap {
  [skill: string]: SkillMetrics;
}

/**
 * Computes skill frequency and market value from LinkedIn job dataset
 * Uses multi-factor weighting: frequency (40%), salary (30%), seniority (30%)
 */
export function computeSkillFrequency(): SkillFrequencyMap {
  const skillMap: {
    [skill: string]: {
      frequency: number;
      salaries: number[];
      requiredCount: number;
      niceToHaveCount: number;
      seniorityScores: number[];
    };
  } = {};

  // Seniority to numeric score mapping
  const seniorityScores = { junior: 1, mid: 2, senior: 3 };

  // Process each job
  jobData.jobs.forEach((job) => {
    const seniorityScore = seniorityScores[job.seniority as keyof typeof seniorityScores] || 2;
    const avgJobSalary = (job.salaryMin + job.salaryMax) / 2;

    // Process required skills
    job.requiredSkills.forEach((skill) => {
      if (!skillMap[skill]) {
        skillMap[skill] = {
          frequency: 0,
          salaries: [],
          requiredCount: 0,
          niceToHaveCount: 0,
          seniorityScores: [],
        };
      }
      skillMap[skill].frequency += 1;
      skillMap[skill].salaries.push(avgJobSalary);
      skillMap[skill].requiredCount += 1;
      skillMap[skill].seniorityScores.push(seniorityScore);
    });

    // Process nice-to-have skills (0.6x weight)
    job.niceToHaveSkills?.forEach((skill) => {
      if (!skillMap[skill]) {
        skillMap[skill] = {
          frequency: 0,
          salaries: [],
          requiredCount: 0,
          niceToHaveCount: 0,
          seniorityScores: [],
        };
      }
      skillMap[skill].frequency += 0.6;
      skillMap[skill].salaries.push(avgJobSalary * 0.8);
      skillMap[skill].niceToHaveCount += 1;
      skillMap[skill].seniorityScores.push(seniorityScore * 0.7);
    });
  });

  // Compute metrics for each skill
  const result: SkillFrequencyMap = {};
  const maxFrequency = Math.max(
    ...Object.values(skillMap).map((s) => s.frequency),
    1
  );
  const allSalaries = Object.values(skillMap).flatMap((s) => s.salaries);
  const maxSalary = Math.max(...allSalaries, 100000);
  const minSalary = Math.min(...allSalaries, 60000);
  const avgAllSalaries = allSalaries.reduce((a, b) => a + b, 0) / allSalaries.length;

  Object.entries(skillMap).forEach(([skill, data]) => {
    // Normalize frequency (0-1)
    const frequencyNorm = data.frequency / maxFrequency;

    // Average salary for this skill
    const avgSalary =
      data.salaries.length > 0
        ? data.salaries.reduce((a, b) => a + b, 0) / data.salaries.length
        : avgAllSalaries;

    // Normalize salary (0-1, higher is better)
    const salaryNorm = (avgSalary - minSalary) / (maxSalary - minSalary);

    // Average seniority level (0-1)
    const avgSeniority =
      data.seniorityScores.length > 0
        ? data.seniorityScores.reduce((a, b) => a + b, 0) / data.seniorityScores.length
        : 2;
    const seniorityNorm = avgSeniority / 3;

    // Multi-factor demand score: 40% frequency + 30% salary + 30% seniority
    const demandScore =
      frequencyNorm * 0.4 + salaryNorm * 0.3 + seniorityNorm * 0.3;

    // Market value combines salary premium and demand
    const salaryPremium = avgSalary > avgAllSalaries ? 1.2 : 0.8;
    const marketValue = demandScore * salaryPremium;

    result[skill] = {
      skill,
      frequency: data.frequency,
      avgSalary: Math.round(avgSalary),
      requiredCount: data.requiredCount,
      niceToHaveCount: data.niceToHaveCount,
      demandScore: Math.round(demandScore * 100) / 100,
      marketValue: Math.round(marketValue * 100) / 100,
    };
  });

  return result;
}

/**
 * Get top N skills by market value
 */
export function getTopSkills(n: number = 10): SkillMetrics[] {
  const skillMap = computeSkillFrequency();
  return Object.values(skillMap)
    .sort((a, b) => b.marketValue - a.marketValue)
    .slice(0, n);
}

/**
 * Get skills ranked by demand score
 */
export function getSkillsByDemand(limit?: number): SkillMetrics[] {
  const skillMap = computeSkillFrequency();
  const sorted = Object.values(skillMap).sort(
    (a, b) => b.demandScore - a.demandScore
  );
  return limit ? sorted.slice(0, limit) : sorted;
}

/**
 * Get skill recommendations for a user based on their current skills
 * Returns high-value skills that complement the user's profile
 */
export function recommendSkillsForUser(
  userSkills: string[],
  limit: number = 5
): SkillMetrics[] {
  const skillMap = computeSkillFrequency();
  const userSkillSet = new Set(userSkills.map((s) => s.toLowerCase()));

  return Object.values(skillMap)
    .filter((skill) => !userSkillSet.has(skill.skill.toLowerCase()))
    .sort((a, b) => b.marketValue - a.marketValue)
    .slice(0, limit);
}

/**
 * Get salary data for a skill
 */
export function getSkillSalaryInfo(skill: string): { avg: number; demand: number } | null {
  const skillMap = computeSkillFrequency();
  const skillData = Object.values(skillMap).find(
    (s) => s.skill.toLowerCase() === skill.toLowerCase()
  );

  if (!skillData) return null;

  return {
    avg: skillData.avgSalary,
    demand: skillData.demandScore,
  };
}
