import { ChatMessage, UserProfile, CareerRoadmap } from '@/lib/types';
import { generateText } from 'ai';

export async function POST(request: Request) {
  try {
    const { messages, profile, roadmap } = await request.json();

    const lastMessage = messages[messages.length - 1];
    if (lastMessage.role !== 'user') {
      return new Response('Invalid message format', { status: 400 });
    }

    // Build context for AI
    const context = buildCareerContext(profile, roadmap);
    const systemPrompt = buildSystemPrompt(context);

    // Convert messages to model format
    const modelMessages = messages.map((msg: ChatMessage) => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content,
    }));

    // Call AI for intelligent response
    try {
      const result = await generateText({
        model: 'openai/gpt-4-turbo',
        system: systemPrompt,
        messages: modelMessages,
        temperature: 0.7,
        maxTokens: 500,
      });

      return new Response(result.text);
    } catch (aiError) {
      // Fallback to rule-based response if AI call fails
      console.log('AI call failed, using fallback response');
      const response = generateAIResponse(
        lastMessage.content,
        profile,
        roadmap,
        messages
      );
      return new Response(response);
    }
  } catch (error) {
    console.error('Chat API Error:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}

function buildCareerContext(profile: UserProfile, roadmap: CareerRoadmap): string {
  const completedTasks = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = roadmap.tasks.length;
  const completionRate = Math.round((completedTasks / totalTasks) * 100);
  const nextTask = roadmap.tasks.find((t) => t.status !== 'completed');

  return `
CAREER PROFILE:
- Name: ${profile.name}
- Current Role: ${profile.currentRole}
- Years of Experience: ${profile.yearsOfExperience}
- Current Skills: ${profile.currentSkills.join(', ')}
- Target Role: ${profile.targetRole || 'Not set'}
- Target Salary: $${profile.targetSalary?.toLocaleString() || 'Not set'}
- Career Goal: ${profile.careerGoal}

PROGRESS STATUS:
- Tasks Completed: ${completedTasks}/${totalTasks} (${completionRate}%)
- Current Phase: ${getPhase(completionRate)}
- Next Task: ${nextTask ? nextTask.title : 'All tasks completed!'}
- Total Time Planned: ${roadmap.tasks.reduce((sum, t) => sum + t.estimatedHours, 0)} hours

KEY SKILLS TO DEVELOP:
${roadmap.tasks
  .filter((t) => t.status !== 'completed')
  .flatMap((t) => t.skills)
  .filter((v, i, a) => a.indexOf(v) === i)
  .slice(0, 5)
  .map((s) => `- ${s}`)
  .join('\n')}
  `.trim();
}

function buildSystemPrompt(context: string): string {
  return `You are an AI Career Coach helping developers advance their careers. You have deep knowledge of:
- Career progression paths in tech
- Market trends and skill demand
- Learning strategies and productivity
- Industry best practices

USER'S CAREER CONTEXT:
${context}

GUIDELINES:
1. Provide specific, actionable advice based on their roadmap and progress
2. Encourage and motivate - acknowledge their progress
3. Offer practical next steps when appropriate
4. Reference their specific skills, goals, and timeline
5. Be concise but informative (2-3 paragraphs max)
6. Adapt advice based on their completion rate and current phase`;
}

function generateAIResponse(
  userMessage: string,
  profile: UserProfile,
  roadmap: CareerRoadmap,
  messages: ChatMessage[]
): string {
  const messageLower = userMessage.toLowerCase();

  // Calculate stats
  const completedTasks = roadmap.tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = roadmap.tasks.length;
  const completionRate = Math.round((completedTasks / totalTasks) * 100);
  const remainingTasks = roadmap.tasks.filter((t) => t.status !== 'completed');
  const nextTask = remainingTasks[0];

  // Generate responses based on common questions
  if (messageLower.includes('progress') || messageLower.includes('how am i')) {
    return `Great question! You're making solid progress on your career journey. You've completed ${completedTasks} out of ${totalTasks} tasks (${completionRate}%). At this pace, you're on track to reach your goal of becoming a ${profile.targetRole} within your planned timeline. Keep up the momentum!`;
  }

  if (messageLower.includes('next') || messageLower.includes('what should i')) {
    if (nextTask) {
      return `Your next priority should be: "${nextTask.title}". This task will help you develop ${nextTask.skills.join(', ')} and is estimated to take about ${nextTask.estimatedHours} hours. I recommend starting with this to build foundational skills for your target role.`;
    }
    return `Congratulations! You've completed all tasks in your roadmap. Your next step is to apply these skills in real-world projects and continue networking to land your target role as a ${profile.targetRole}.`;
  }

  if (messageLower.includes('skill') || messageLower.includes('learn')) {
    const unlearned = roadmap.tasks
      .filter((t) => t.status !== 'completed')
      .flatMap((t) => t.skills)
      .filter((v, i, a) => a.indexOf(v) === i);
    return `Based on market demand analysis, the most valuable skills for your target role are: ${unlearned.slice(0, 3).join(', ')}. I recommend prioritizing these in your learning plan. The job market shows strong demand for these skills with average salaries ${Math.round(profile.targetSalary ? profile.targetSalary * 0.1 : 10000)} higher than your current level.`;
  }

  if (messageLower.includes('accelerate') || messageLower.includes('faster')) {
    return `To accelerate your progress, I suggest: 1) Focus on high-impact projects that combine multiple skills, 2) Contribute to open source to gain real-world experience, 3) Set a target to complete one task every 2 weeks, 4) Join communities related to your target role. These strategies can help you shorten your timeline by 20-30%.`;
  }

  if (messageLower.includes('goal') || messageLower.includes('target')) {
    return `Your career goal is to advance to a ${profile.targetRole} role with a target salary of $${profile.targetSalary?.toLocaleString()}. Your roadmap spans ${roadmap.tasks.length} tasks organized in 4 phases: Foundation, Growth, Mastery, and Leadership. You're currently in the ${getPhase(completionRate)} phase.`;
  }

  if (messageLower.includes('motivation') || messageLower.includes('discouraged')) {
    return `You're doing great! Progress in career development isn't always linear, but you've already completed ${completionRate}% of your roadmap. Remember that ${profile.targetRole} professionals didn't get there overnight. Every task you complete is building valuable skills. Let's focus on your next milestone!`;
  }

  // Default response
  return `I'm your AI Career Coach, here to help you reach your goal of becoming a ${profile.targetRole}. You can ask me about:
- Your progress and current phase
- What task to tackle next
- Skills to prioritize for your target role
- Ways to accelerate your learning
- Motivation and career planning advice

You've completed ${completionRate}% of your roadmap. What would you like to know?`;
}

function getPhase(completionRate: number): string {
  if (completionRate < 25) return 'Foundation';
  if (completionRate < 50) return 'Growth';
  if (completionRate < 75) return 'Mastery';
  return 'Leadership';
}
