import { runEvolution, EvolutionInput } from '@/lib/agents/evolution';

export async function POST(request: Request) {
  try {
    const input: EvolutionInput = await request.json();

    const result = await runEvolution(input);

    return Response.json(result);
  } catch (error) {
    console.error('Evolution Agent Error:', error);
    return Response.json(
      { error: 'Failed to evaluate and evolve roadmap' },
      { status: 500 }
    );
  }
}
