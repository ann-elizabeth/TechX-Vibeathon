import { runGoalSetter, GoalSetterInput } from '@/lib/agents/goal-setter';

export async function POST(request: Request) {
  try {
    const input: GoalSetterInput = await request.json();

    const result = await runGoalSetter(input);

    return Response.json(result);
  } catch (error) {
    console.error('Goal Setter Agent Error:', error);
    return Response.json(
      { error: 'Failed to generate career goal' },
      { status: 500 }
    );
  }
}
