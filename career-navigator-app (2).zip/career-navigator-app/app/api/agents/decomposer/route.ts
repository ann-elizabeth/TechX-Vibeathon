import { runDecomposer, DecomposerInput } from '@/lib/agents/decomposer';

export async function POST(request: Request) {
  try {
    const input: DecomposerInput = await request.json();

    const result = await runDecomposer(input);

    return Response.json(result);
  } catch (error) {
    console.error('Task Decomposer Agent Error:', error);
    return Response.json(
      { error: 'Failed to decompose goal into tasks' },
      { status: 500 }
    );
  }
}
