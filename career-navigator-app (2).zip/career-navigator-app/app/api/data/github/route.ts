import { GitHubActivity } from '@/lib/types';

/**
 * GitHub Activity Fetcher
 * Fetches recent GitHub activity for a user
 * In production, this would call the GitHub API
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const username = searchParams.get('username');

  if (!username) {
    return Response.json(
      { error: 'Username parameter required' },
      { status: 400 }
    );
  }

  try {
    // In production, you would make real GitHub API calls here
    // For now, we'll return mock data
    const mockActivity: GitHubActivity = {
      username,
      lastFetched: new Date(),
      commitCount: 45,
      recentProjects: [
        {
          name: 'career-navigator-app',
          url: `https://github.com/${username}/career-navigator-app`,
          language: 'TypeScript',
          stars: 12,
        },
        {
          name: 'ai-agent-system',
          url: `https://github.com/${username}/ai-agent-system`,
          language: 'Python',
          stars: 8,
        },
        {
          name: 'skill-mapper',
          url: `https://github.com/${username}/skill-mapper`,
          language: 'JavaScript',
          stars: 5,
        },
      ],
      contributions: {
        thisWeek: 15,
        thisMonth: 45,
        total: 234,
      },
    };

    return Response.json(mockActivity);
  } catch (error) {
    console.error('GitHub API Error:', error);
    return Response.json(
      { error: 'Failed to fetch GitHub activity' },
      { status: 500 }
    );
  }
}
