import {
  getTopSkills,
  getSkillsByDemand,
  recommendSkillsForUser,
} from '@/lib/skill-engine';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');
  const limit = parseInt(searchParams.get('limit') || '10', 10);

  try {
    if (action === 'top') {
      const skills = getTopSkills(limit);
      return Response.json({ skills });
    } else if (action === 'by-demand') {
      const skills = getSkillsByDemand(limit);
      return Response.json({ skills });
    } else if (action === 'recommend') {
      const userSkillsParam = searchParams.get('userSkills');
      const userSkills = userSkillsParam ? userSkillsParam.split(',') : [];
      const skills = recommendSkillsForUser(userSkills, limit);
      return Response.json({ skills });
    } else {
      return Response.json(
        { error: 'Invalid action. Use: top, by-demand, or recommend' },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Skills API Error:', error);
    return Response.json(
      { error: 'Failed to fetch skills data' },
      { status: 500 }
    );
  }
}
