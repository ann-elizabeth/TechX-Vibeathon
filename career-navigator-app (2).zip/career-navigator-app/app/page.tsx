'use client';

import { useState, useEffect } from 'react';
import { OnboardingFlow } from '@/components/onboarding-flow';
import { Dashboard } from '@/components/dashboard';
import { clientStorage } from '@/lib/storage';
import { UserProfile } from '@/lib/types';

export default function Home() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedProfile = clientStorage.getProfile();
    setProfile(savedProfile);
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return profile ? <Dashboard profile={profile} /> : <OnboardingFlow />;
}
